<template>
    <q-page padding>
      <div class="row q-mb-md">
        <q-btn
          color="primary"
          label="New Post"
          @click="$router.push('/posts/new')"
        />
      </div>
  
      <q-list bordered separator v-if="!loading && posts.length">
        <q-item
          v-for="post in posts"
          :key="post.id"
          clickable
          @click="$router.push(`/posts/${post.id}`)"
        >
          <q-item-section>
            <q-item-label>{{ post.title }}</q-item-label>
            <q-item-label caption>{{ post.category }}</q-item-label>
          </q-item-section>
        </q-item>
      </q-list>
  
      <q-inner-loading :showing="loading" />
    </q-page>
  </template>
  
  <script setup lang="ts">
  import { useBlogStore } from '@/stores/blog'
  import { onMounted } from 'vue'
  
  const { posts, loading, fetchPosts } = useBlogStore()
  
  onMounted(() => {
    fetchPosts()
  })
  </script>