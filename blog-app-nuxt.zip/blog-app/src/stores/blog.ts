import { defineStore } from 'pinia'
import { ref } from 'vue'
import axios from 'axios'

interface Post {
  id: number
  title: string
  content: string
  category: string
  createdAt: string
}

export const useBlogStore = defineStore('blog', () => {
  const posts = ref<Post[]>([])
  const loading = ref(false)
  const error = ref<string | null>(null)

  const fetchPosts = async () => {
    try {
      loading.value = true
      const response = await axios.get('http://localhost:3000/posts')
      posts.value = response.data
    } catch (err) {
      error.value = 'Failed to fetch posts'
    } finally {
      loading.value = false
    }
  }

  const addPost = async (post: Omit<Post, 'id' | 'createdAt'>) => {
    try {
      const response = await axios.post('http://localhost:3000/posts', {
        ...post,
        createdAt: new Date().toISOString()
      })
      posts.value.push(response.data)
      return response.data
    } catch (err) {
      error.value = 'Failed to add post'
      throw err
    }
  }

  return { posts, loading, error, fetchPosts, addPost }
})